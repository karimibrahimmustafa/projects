package eg.edu.alexu.csd.oop.draw;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.swing.*;



public class test {
	public static void main(String args[]) throws Exception {
	    JFrame f = new JFrame("Draw a Red Line");
	    
	    
	    ArrayList<Shape> shapes = new ArrayList<>();
	    f.setSize(500, 500);
	    f.setLocation(300, 300);
	    f.setResizable(false);
	    JPanel p = new JPanel() {
	        Point pointStart = null;
	        Point pointEnd   = null;
	        {
	        	Shape line = new LineSegment();
	        	Map<String, Double> properties = new HashMap<>();
		       
	            addMouseListener(new MouseAdapter() {
	                public void mousePressed(MouseEvent e) {
	                    pointStart = e.getPoint();
	                    
	                    properties.put("startPointx",(double)pointStart.x);
	    		        properties.put("startPointy",(double)pointStart.y);	
	                    
	                }

	                public void mouseReleased(MouseEvent e) {
	                    pointStart = null;
	                    shapes.add(line);
	                }
	            });
	            addMouseMotionListener(new MouseMotionAdapter() {
	                public void mouseMoved(MouseEvent e) {
	                    pointEnd = e.getPoint();
	                    
	                    properties.put("endPointx",(double)pointEnd.x);
	    		        properties.put("endPointy",(double)pointEnd.y);	
	                }

	                public void mouseDragged(MouseEvent e) {
	                    pointEnd = e.getPoint();
	                    
	                    properties.put("endPointx",(double)pointEnd.x);
	    		        properties.put("endPointy",(double)pointEnd.y);	
	    		        
	                    repaint();
	                }
	            });
	        }
	        public void paint(Graphics g) {
	            super.paint(g);
	            if (pointStart != null) {
	                g.setColor(Color.RED);
/*	                for(int i = 0; i < shapes.size(); i++) {
	                	shapes.get(i).draw(g);
	                }
	                */
	                g.drawLine(pointStart.x, pointStart.y, pointEnd.x, pointEnd.y);
	                
	            }
	        }
	    };
	    f.add(p);
	    f.setVisible(true); 
	}

}
